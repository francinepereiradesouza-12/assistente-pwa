# Assistente Pessoal — PWA

App de gestão de tarefas com IA integrada, instalável no celular.

## Como instalar em 5 minutos (GitHub Pages — gratuito)

1. Crie uma conta em https://github.com
2. Clique em "New repository" → nome: `assistente-pwa` → marque "Public" → Create
3. Arraste os 3 arquivos (index.html, manifest.json, sw.js) para dentro do repositório
4. Vá em Settings → Pages → Source: `main` → Save
5. Seu app estará em: `https://SEU_USUARIO.github.io/assistente-pwa`

## Adicionar ao celular (iOS)
1. Abra o link no Safari
2. Toque em Compartilhar (ícone de caixa com seta)
3. "Adicionar à Tela de Início"
4. Pronto — ícone na tela inicial como um app nativo!

## Adicionar ao celular (Android)
1. Abra o link no Chrome
2. Banner aparece automaticamente: "Adicionar à tela inicial"
3. Ou: menu (⋮) → "Adicionar à tela inicial"

## Configurar a IA

Para ativar o assistente IA, você precisa de uma chave da API Anthropic:
1. Acesse https://console.anthropic.com
2. Crie uma chave em "API Keys"
3. No arquivo index.html, encontre a linha:
   `const ANTHROPIC_KEY = '';`
4. Cole sua chave entre as aspas:
   `const ANTHROPIC_KEY = 'sk-ant-...';`

## Ícones (opcional)
Coloque dois arquivos PNG na pasta `icons/`:
- `icon-192.png` (192x192 px)
- `icon-512.png` (512x512 px)

Use qualquer ícone de sua preferência.

## Funcionalidades
- ✅ Tarefas por categoria: Meta Ads, Reuniões, Pessoal, Relatórios
- ✅ Prioridade urgente com destaque visual
- ✅ Dados salvos localmente (funciona offline)
- ✅ Assistente IA com contexto de todas as suas tarefas
- ✅ Instalável como app no iOS e Android
- ✅ Interface dark mode otimizada para mobile
